package dominoes;

public class DominoRepresentationConstants_Jowad {
    public static final char HIGH_LOW_STRING_SEPARATOR = ':';
    public static final char SUM_DIFFERENCE_DELIMITER = ',';
    public static final char LOW_DIFFERENCE_DELIMITER = '*';
}
